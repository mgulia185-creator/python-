import csv
import os
from datetime import datetime
from collections import defaultdict

DATA_FILE = "expenses.csv"
FIELDS = ["date", "category", "amount", "description"]


def load_expenses():
    """Load saved expenses from CSV."""
    expenses = []
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", newline="", encoding="utf-8") as file:
                reader = csv.DictReader(file)
                for row in reader:
                    try:
                        amount = float(row["amount"])
                        datetime.strptime(row["date"], "%Y-%m-%d")
                        expenses.append({
                            "date": row["date"],
                            "category": row["category"],
                            "amount": amount,
                            "description": row.get("description", "")
                        })
                    except (ValueError, KeyError, TypeError):
                        continue
        except (OSError, csv.Error) as error:
            print(f"Could not read saved data: {error}")
    return expenses


def save_expenses(expenses):
    """Save expenses to CSV."""
    try:
        with open(DATA_FILE, "w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=FIELDS)
            writer.writeheader()
            for expense in expenses:
                writer.writerow(expense)
        return True
    except OSError as error:
        print(f"Could not save data: {error}")
        return False


def add_expense(expenses):
    try:
        amount = float(input("Amount (₹): ").strip())
        if amount <= 0:
            print("Amount must be greater than zero.")
            return
    except ValueError:
        print("Invalid amount. Enter a number, for example 125.50.")
        return

    category = input("Category (Food/Transport/Bills/Shopping/Other): ").strip()
    if not category:
        print("Category cannot be empty.")
        return

    date_text = input("Date YYYY-MM-DD (press Enter for today): ").strip()
    if not date_text:
        date_text = datetime.today().strftime("%Y-%m-%d")
    try:
        datetime.strptime(date_text, "%Y-%m-%d")
    except ValueError:
        print("Invalid date. Use YYYY-MM-DD, for example 2026-10-29.")
        return

    description = input("Description (optional): ").strip()
    expenses.append({
        "date": date_text,
        "category": category.title(),
        "amount": round(amount, 2),
        "description": description
    })
    if save_expenses(expenses):
        print("Expense added and saved successfully.")


def view_expenses(expenses):
    if not expenses:
        print("No expenses recorded yet.")
        return
    print("\n{:<12} {:<16} {:>12}  {}".format("Date", "Category", "Amount (₹)", "Description"))
    print("-" * 68)
    for item in sorted(expenses, key=lambda x: x["date"], reverse=True):
        print("{:<12} {:<16} {:>12.2f}  {}".format(
            item["date"], item["category"], item["amount"], item["description"]))
    print("-" * 68)
    print(f"Number of expenses: {len(expenses)}")


def generate_report(expenses):
    if not expenses:
        print("No expenses available for a report.")
        return
    total = sum(item["amount"] for item in expenses)
    by_category = defaultdict(float)
    by_month = defaultdict(float)
    for item in expenses:
        by_category[item["category"]] += item["amount"]
        by_month[item["date"][:7]] += item["amount"]

    highest = max(expenses, key=lambda x: x["amount"])
    print("\n--- Expense Report ---")
    print(f"Total spent: ₹{total:.2f}")
    print(f"Average expense: ₹{total / len(expenses):.2f}")
    print(f"Highest expense: ₹{highest['amount']:.2f} ({highest['category']}, {highest['date']})")
    print("\nCategory-wise spending:")
    for category, amount in sorted(by_category.items(), key=lambda pair: pair[1], reverse=True):
        print(f"  {category:<16} ₹{amount:.2f}")
    print("\nMonthly spending:")
    for month, amount in sorted(by_month.items()):
        print(f"  {month}: ₹{amount:.2f}")


def show_chart(expenses):
    if not expenses:
        print("Add some expenses before creating a chart.")
        return
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("Matplotlib is not installed. Run: python -m pip install matplotlib")
        return

    totals = defaultdict(float)
    for item in expenses:
        totals[item["category"]] += item["amount"]

    categories = list(totals.keys())
    amounts = list(totals.values())
    plt.figure(figsize=(8, 5))
    plt.bar(categories, amounts)
    plt.title("Spending by Category")
    plt.xlabel("Category")
    plt.ylabel("Amount (₹)")
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.show()


def main():
    expenses = load_expenses()
    print("=" * 42)
    print("       PERSONAL EXPENSE TRACKER")
    print("=" * 42)
    while True:
        print("\n1. Add an Expense")
        print("2. View All Expenses")
        print("3. Generate Report")
        print("4. Show Category Chart")
        print("5. Save and Exit")
        choice = input("Enter your choice (1-5): ").strip()

        if choice == "1":
            add_expense(expenses)
        elif choice == "2":
            view_expenses(expenses)
        elif choice == "3":
            generate_report(expenses)
        elif choice == "4":
            show_chart(expenses)
        elif choice == "5":
            if save_expenses(expenses):
                print("Data saved. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a number from 1 to 5.")


if __name__ == "__main__":
    main()
