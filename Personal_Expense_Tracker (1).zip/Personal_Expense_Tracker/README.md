# Personal Expense Tracker

A beginner-friendly command-line Python project based on the supplied major-project brief.

## Features
- Add expenses with amount, category, date, and optional description
- View saved expenses
- CSV persistence (`expenses.csv`)
- Total, average, highest, category-wise, and monthly reports
- Category bar chart using Matplotlib
- Input validation and exception handling

## Requirements
- Python 3.9 or newer
- Matplotlib (only required for charts)

## Run in VS Code
1. Extract the ZIP and open the `Personal_Expense_Tracker` folder in VS Code.
2. Open the terminal: **Terminal > New Terminal**.
3. Optional: install chart library:
   ```bash
   python -m pip install matplotlib
   ```
4. Run:
   ```bash
   python main.py
   ```
   On some Windows setups, use `py main.py`.

The first run creates `expenses.csv` when data is saved. Keep this file in the same folder as `main.py` so your history remains available.

## Menu
1. Add an Expense
2. View All Expenses
3. Generate Report
4. Show Category Chart
5. Save and Exit
